#The Linked List and Node classes came from zyBooks
class Node:
    def __init__(self, state, year, name):
        self.state = state
        self.year = year
        self.name = name
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def append(self, new_node):
        if self.head == None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

    def prepend(self, new_node):
        if self.head == None:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node

    def insert_after(self, current_node, new_node):
        if self.head == None:
            self.head = new_node
            self.tail = new_node
        elif current_node is self.tail:
            self.tail.next = new_node
            self.tail = new_node
        else:
            new_node.next = current_node.next
            current_node.next = new_node
   
    def remove_after(self, current_node):
        # Special case, remove head
        if (current_node == None) and (self.head != None):
            succeeding_node = self.head.next
            self.head = succeeding_node  
            if succeeding_node == None: # Remove last item
                self.tail = None
        elif current_node.next != None:
            succeeding_node = current_node.next.next
            current_node.next = succeeding_node
            if succeeding_node == None: # Remove tail
                self.tail = current_node
     
    def printList(self):
      node = self.head
      while node != None:
        print(node.state,node.year,node.name)
        node = node.next
      
    def search(self, key):
      node = self.head
      while node != None:
        if (node.name.startswith(key)):
          return node
        node = node.next
      return None
            
    def stateSearch(self, state):
      node = self.head
      stateCT = 0
      while node != None:
        if node.state == state:
          stateCT+=1
        node = node.next
      return stateCT
      
    def checkSouth(self):
      south = ['Arkansas','Louisiana','Texas','Oklahoma',
                'Washington_D.C.','Delaware','Maryland','Virginia',
                'West_Virginia','Alabama','Kentucky','North_Carolina',
                'South_Carolina','Tennessee','Georgia','Florida','Mississippi']
      node = self.head
      southCT = 0
      while node != None:
        if node.state in south:
          southCT+=1 
        node = node.next
      return southCT
      
    def reconstruction(self):
      node = self.head
      recoCT = 0
      hbcuCT = 0
      while node != None:
        hbcuCT+=1
        if 1863<=node.year<=1877:
          recoCT+=1
        node = node.next
      return recoCT,hbcuCT
          
def main():
  hbcu = LinkedList()
  
  infile = open('HBCU_List.csv','r')
  info = infile.readline().rstrip()
  while info != '':
    info = info.split(',')
    info[1]=int(info[1])
    node = Node(info[0],info[1],info[2])
    hbcu.append(node)
    info = infile.readline().rstrip()
    
  again = 'y'
  while (again == 'y'):
    user = input("Please enter a University to search:")
    found = hbcu.search(user)
    if found != None:
      print("Found it!")
    else:
      print(user," Was Not Found :(")
    again = input('Type y to search for another college')
  
  state = input("Which state (spelled out) to count colleges?")
  result = hbcu.stateSearch(state)
  print("There are",result,"HBCUs in",state)
  print("There are",hbcu.checkSouth(),"in the south.")
  
  r , h=hbcu.reconstruction()
  print(format(r/h,'.1%'),'of HBCUs were founded during reconstruction')

main()
            